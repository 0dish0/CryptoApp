package com.example.miniproject;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.miniproject.databinding.FragmentTextEncryptionBinding;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import androidx.recyclerview.widget.LinearLayoutManager;
import java.util.List;

public class TextEncryptionFragment extends Fragment {

    private FragmentTextEncryptionBinding binding;
    private EncryptionAlgorithmManager algorithmManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Add Material Motion transition
        if (container != null) {
            setEnterTransition(new android.transition.Fade());
            setExitTransition(new android.transition.Fade());
        }
        
        binding = FragmentTextEncryptionBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize algorithm manager
        algorithmManager = EncryptionAlgorithmManager.getInstance(requireContext());
        algorithmManager.loadAlgorithm();

        // Update algorithm card display
        updateAlgorithmCard();

        // Set up algorithm card click listener
        binding.algorithmCard.setOnClickListener(v -> showAlgorithmDialog());

        // Set up PBE toggle
        binding.pbeToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            binding.passwordInputLayout.setVisibility(isChecked ? View.VISIBLE : View.GONE);
        });

        binding.encryptButton.setOnClickListener(v -> processText(false));
        binding.decryptButton.setOnClickListener(v -> processText(true));

        binding.clearButton.setOnClickListener(v -> {
            binding.textInput.setText("");
            binding.resultView.setText("");
        });

        binding.copyButton.setOnClickListener(v -> {
            String result = binding.resultView.getText().toString();
            if (!result.isEmpty()) {
                ClipboardManager clipboard = (ClipboardManager) requireActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Encrypted/Decrypted Text", result);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getContext(), "Result copied to clipboard", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up Recent Activity section
        setupRecentActivity();
    }

    private void setupRecentActivity() {
        List<HistoryItem> recentItems = HistoryRepository.getInstance().getRecentItems(10);
        RecentActivityAdapter adapter = new RecentActivityAdapter(recentItems, item -> {
            // Navigate to appropriate fragment based on file type
            androidx.navigation.NavController navController = androidx.navigation.Navigation.findNavController(requireView());
            switch (item.getFileType()) {
                case "text":
                    navController.navigate(R.id.textEncryptionFragment);
                    break;
                case "image":
                    navController.navigate(R.id.imageEncryptionFragment);
                    break;
                case "pdf":
                    navController.navigate(R.id.pdfEncryptionFragment);
                    break;
                case "audio":
                    navController.navigate(R.id.audioEncryptionFragment);
                    break;
                case "video":
                    navController.navigate(R.id.videoEncryptionFragment);
                    break;
            }
        });
        binding.recentActivityRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recentActivityRecyclerView.setAdapter(adapter);
        
        // Hide card if no recent items
        if (recentItems.isEmpty()) {
            binding.recentActivityCard.setVisibility(View.GONE);
        }
    }

    private void updateAlgorithmCard() {
        String algorithmName = algorithmManager.getCurrentAlgorithmName();
        binding.algorithmText.setText("Current Algorithm: " + algorithmName);
    }

    private void showAlgorithmDialog() {
        String[] algorithms = {"AES", "XOR Cipher", "Twofish", "Serpent", "Custom"};
        String currentAlgorithm = algorithmManager.getCurrentAlgorithmName();
        int selectedIndex = 0;
        
        switch (currentAlgorithm.toUpperCase()) {
            case "XOR":
                selectedIndex = 1;
                break;
            case "TWOFISH":
                selectedIndex = 2;
                break;
            case "SERPENT":
                selectedIndex = 3;
                break;
            case "CUSTOM":
                selectedIndex = 4;
                break;
            default:
                selectedIndex = 0; // AES
                break;
        }

        MaterialAlertDialogBuilder dialogBuilder = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Select Algorithm")
                .setSingleChoiceItems(algorithms, selectedIndex, (dialog, which) -> {
                    String algorithm;
                    switch (which) {
                        case 1:
                            algorithm = "XOR";
                            break;
                        case 2:
                            algorithm = "Twofish";
                            break;
                        case 3:
                            algorithm = "Serpent";
                            break;
                        case 4:
                            algorithm = "CUSTOM";
                            break;
                        default:
                            algorithm = "AES";
                            break;
                    }
                    algorithmManager.setAlgorithm(algorithm);
                    updateAlgorithmCard();
                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", null);
        
        androidx.appcompat.app.AlertDialog dialog = dialogBuilder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
        }
        dialog.show();
    }

    private void processText(boolean isDecrypt) {
        if (binding.textInput.getText() == null) {
            Toast.makeText(getContext(), "Input cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        String inputText = binding.textInput.getText().toString();

        if (inputText.isEmpty()) {
            Toast.makeText(getContext(), "Input cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean usePassword = binding.pbeToggle.isChecked();
        
        if (usePassword) {
            String password = binding.passwordInput.getText() != null ? binding.passwordInput.getText().toString() : "";
            if (password.isEmpty()) {
                Toast.makeText(getContext(), "Please enter a password", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        try {
            if (isDecrypt) {
                if (EncryptionUtils.isBase64(inputText)) {
                    String decryptedText;
                    boolean isPasswordMode = false;
                    if (usePassword) {
                        String password = binding.passwordInput.getText().toString();
                        decryptedText = algorithmManager.decryptStringWithPassword(inputText, password.toCharArray());
                        isPasswordMode = true;
                    } else {
                        decryptedText = algorithmManager.decryptString(inputText);
                    }
                    binding.resultView.setText(decryptedText);
                    HistoryRepository.getInstance().addHistoryItem(
                        new HistoryItem("Decrypted: " + decryptedText, System.currentTimeMillis(), "text", 
                            decryptedText.length() > 20 ? decryptedText.substring(0, 20) + "..." : decryptedText, isPasswordMode));
                } else {
                    Toast.makeText(getContext(), "Input is not valid Base64 text", Toast.LENGTH_SHORT).show();
                }
            } else {
                String encryptedText;
                boolean isPasswordMode = false;
                if (usePassword) {
                    String password = binding.passwordInput.getText().toString();
                    encryptedText = algorithmManager.encryptStringWithPassword(inputText, password.toCharArray());
                    isPasswordMode = true;
                } else {
                    encryptedText = algorithmManager.encryptString(inputText);
                }
                binding.resultView.setText(encryptedText);
                String preview = inputText.length() > 20 ? inputText.substring(0, 20) + "..." : inputText;
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Encrypted: " + encryptedText, System.currentTimeMillis(), "text", preview, isPasswordMode));
            }
        } catch (Exception e) {
            Log.e("TextEncryptionFragment", "Processing error", e);
            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload algorithm in case it was changed elsewhere
        if (algorithmManager != null) {
            algorithmManager.loadAlgorithm();
            updateAlgorithmCard();
        }
        // Refresh recent activity
        setupRecentActivity();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
