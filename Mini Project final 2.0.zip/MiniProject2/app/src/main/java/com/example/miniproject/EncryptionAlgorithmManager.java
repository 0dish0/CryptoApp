package com.example.miniproject;

import android.content.Context;

import java.io.InputStream;
import java.io.OutputStream;

import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Manager for encryption algorithms.
 * Handles algorithm selection, key generation, and provides unified encryption/decryption interface.
 */
public class EncryptionAlgorithmManager {
    
    private static final String DEFAULT_ALGORITHM = "AES";
    private static final int KEY_LENGTH = 256;
    private static final int PBKDF2_ITERATIONS = 65536;
    private static final int PBE_ITERATIONS = 10000; // For password-based encryption
    private static final int SALT_SIZE = 16;
    private static final byte[] FIXED_SALT = new byte[] { 
        (byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, 
        (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03, 
        (byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, 
        (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03 
    };
    private static final String XOR_KEY = "default_key";
    
    private static EncryptionAlgorithmManager instance;
    private Context context;
    private CustomEncryptionAlgorithm currentAlgorithm;
    
    private EncryptionAlgorithmManager(Context context) {
        this.context = context.getApplicationContext();
        loadAlgorithm();
    }
    
    public static synchronized EncryptionAlgorithmManager getInstance(Context context) {
        if (instance == null) {
            instance = new EncryptionAlgorithmManager(context);
        }
        return instance;
    }
    
    /**
     * Loads the current algorithm from preferences and initializes it.
     */
    public void loadAlgorithm() {
        String algorithmName = AlgorithmPreferences.getAlgorithm(context);
        setAlgorithm(algorithmName);
    }
    
    /**
     * Sets the current algorithm.
     * @param algorithmName Name of the algorithm (AES, XOR, Twofish, Serpent, CUSTOM)
     */
    public void setAlgorithm(String algorithmName) {
        String normalizedName = algorithmName.toUpperCase();
        switch (normalizedName) {
            case "AES":
                currentAlgorithm = new AESEncryptionAlgorithm();
                break;
            case "XOR":
                currentAlgorithm = new XOREncryptionAlgorithm();
                break;
            case "TWOFISH":
                currentAlgorithm = new TwofishEncryptionAlgorithm();
                break;
            case "SERPENT":
                currentAlgorithm = new SerpentEncryptionAlgorithm();
                break;
            case "CUSTOM":
                // Placeholder - uses AES as fallback
                currentAlgorithm = new AESEncryptionAlgorithm();
                break;
            default:
                currentAlgorithm = new AESEncryptionAlgorithm();
                normalizedName = "AES";
                break;
        }
        
        // Store the normalized name (uppercase) for consistency
        AlgorithmPreferences.setAlgorithm(context, normalizedName);
    }
    
    /**
     * Gets the current algorithm instance.
     * @return Current encryption algorithm
     */
    public CustomEncryptionAlgorithm getCurrentAlgorithm() {
        return currentAlgorithm;
    }
    
    /**
     * Gets the name of the current algorithm.
     * @return Algorithm name
     */
    public String getCurrentAlgorithmName() {
        return currentAlgorithm != null ? currentAlgorithm.getAlgorithmName() : DEFAULT_ALGORITHM;
    }
    
    /**
     * Encrypts a string using the current algorithm.
     * @param plainText Text to encrypt
     * @return Base64-encoded encrypted string
     * @throws Exception If encryption fails
     */
    public String encryptString(String plainText) throws Exception {
        Object key = generateKeyForCurrentAlgorithm();
        return currentAlgorithm.encryptString(plainText, key);
    }

    /**
     * Encrypts a string using password-based encryption (PBE).
     * @param plainText Text to encrypt
     * @param password User-provided password
     * @return Base64-encoded encrypted string
     * @throws Exception If encryption fails
     */
    public String encryptStringWithPassword(String plainText, char[] password) throws Exception {
        SecretKey key = generatePasswordBasedKey(password);
        return currentAlgorithm.encryptString(plainText, key);
    }
    
    /**
     * Decrypts a string using the current algorithm.
     * @param encryptedText Base64-encoded encrypted text
     * @return Decrypted plain text
     * @throws Exception If decryption fails
     */
    public String decryptString(String encryptedText) throws Exception {
        Object key = generateKeyForCurrentAlgorithm();
        return currentAlgorithm.decryptString(encryptedText, key);
    }

    /**
     * Decrypts a string using password-based encryption (PBE).
     * @param encryptedText Base64-encoded encrypted text
     * @param password User-provided password
     * @return Decrypted plain text
     * @throws Exception If decryption fails
     */
    public String decryptStringWithPassword(String encryptedText, char[] password) throws Exception {
        SecretKey key = generatePasswordBasedKey(password);
        return currentAlgorithm.decryptString(encryptedText, key);
    }
    
    /**
     * Encrypts a stream using the current algorithm.
     * @param inputStream Source stream
     * @param outputStream Destination stream
     * @throws Exception If encryption fails
     */
    public void encryptStream(InputStream inputStream, OutputStream outputStream) throws Exception {
        if (!currentAlgorithm.supportsStreamEncryption()) {
            throw new UnsupportedOperationException(
                "Stream encryption not supported for " + currentAlgorithm.getAlgorithmName());
        }
        Object key = generateKeyForCurrentAlgorithm();
        currentAlgorithm.encryptStream(inputStream, outputStream, key);
    }

    /**
     * Encrypts a stream using password-based encryption (PBE).
     * @param inputStream Source stream
     * @param outputStream Destination stream
     * @param password User-provided password
     * @throws Exception If encryption fails
     */
    public void encryptStreamWithPassword(InputStream inputStream, OutputStream outputStream, char[] password) throws Exception {
        if (!currentAlgorithm.supportsStreamEncryption()) {
            throw new UnsupportedOperationException(
                "Stream encryption not supported for " + currentAlgorithm.getAlgorithmName());
        }
        SecretKey key = generatePasswordBasedKey(password);
        currentAlgorithm.encryptStream(inputStream, outputStream, key);
    }
    
    /**
     * Decrypts a stream using the current algorithm.
     * @param inputStream Source stream
     * @param outputStream Destination stream
     * @throws Exception If decryption fails
     */
    public void decryptStream(InputStream inputStream, OutputStream outputStream) throws Exception {
        if (!currentAlgorithm.supportsStreamEncryption()) {
            throw new UnsupportedOperationException(
                "Stream decryption not supported for " + currentAlgorithm.getAlgorithmName());
        }
        Object key = generateKeyForCurrentAlgorithm();
        currentAlgorithm.decryptStream(inputStream, outputStream, key);
    }

    /**
     * Decrypts a stream using password-based encryption (PBE).
     * @param inputStream Source stream
     * @param outputStream Destination stream
     * @param password User-provided password
     * @throws Exception If decryption fails
     */
    public void decryptStreamWithPassword(InputStream inputStream, OutputStream outputStream, char[] password) throws Exception {
        if (!currentAlgorithm.supportsStreamEncryption()) {
            throw new UnsupportedOperationException(
                "Stream decryption not supported for " + currentAlgorithm.getAlgorithmName());
        }
        SecretKey key = generatePasswordBasedKey(password);
        currentAlgorithm.decryptStream(inputStream, outputStream, key);
    }
    
    /**
     * Generates an appropriate key for the current algorithm.
     * @return Key object (SecretKey for block ciphers, String for XOR)
     */
    private Object generateKeyForCurrentAlgorithm() throws Exception {
        String algorithmName = getCurrentAlgorithmName();
        
        if ("XOR".equals(algorithmName)) {
            return XOR_KEY;
        } else {
            // Generate SecretKey for block ciphers (AES, Twofish, Serpent)
            return generateSecretKey("password".toCharArray(), FIXED_SALT);
        }
    }
    
    /**
     * Generates a SecretKey using PBKDF2.
     * @param password Password
     * @param salt Salt
     * @return SecretKey
     */
    public static SecretKey generateSecretKey(char[] password, byte[] salt) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password, salt, PBKDF2_ITERATIONS, KEY_LENGTH);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }

    /**
     * Generates a SecretKey from password using PBKDF2 with SHA-256 and 10000 iterations (PBE mode).
     * @param password User-provided password
     * @return SecretKey for AES encryption
     * @throws Exception If key generation fails
     */
    private SecretKey generatePasswordBasedKey(char[] password) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password, FIXED_SALT, PBE_ITERATIONS, KEY_LENGTH);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }
    
    /**
     * Checks if the current algorithm supports stream encryption.
     * @return true if stream encryption is supported
     */
    public boolean supportsStreamEncryption() {
        return currentAlgorithm != null && currentAlgorithm.supportsStreamEncryption();
    }
}

