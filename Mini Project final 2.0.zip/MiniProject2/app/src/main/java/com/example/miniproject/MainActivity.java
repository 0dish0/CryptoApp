package com.example.miniproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.miniproject.databinding.ActivityMainBinding;
import com.example.miniproject.databinding.BottomSheetFabBinding;
import com.google.android.material.bottomsheet.BottomSheetDialog;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);
        NavController navController = navHostFragment.getNavController();

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.textEncryptionFragment, R.id.historyFragment, R.id.settingsFragment, R.id.aboutFragment)
                .build();

        NavigationUI.setupWithNavController(binding.toolbar, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.bottomNavigation, navController);

        // Set up FAB click listener
        binding.fab.setOnClickListener(v -> showBottomSheet(navController));
    }

    private void showBottomSheet(NavController navController) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        BottomSheetFabBinding bottomSheetBinding = BottomSheetFabBinding.inflate(getLayoutInflater());
        bottomSheetDialog.setContentView(bottomSheetBinding.getRoot());
        
        // Add Material Motion animation for bottom sheet
        if (bottomSheetDialog.getWindow() != null) {
            bottomSheetDialog.getWindow().getAttributes().windowAnimations = R.style.BottomSheetAnimation;
        }

        bottomSheetBinding.option1.setOnClickListener(v -> {
            navController.navigate(R.id.textEncryptionFragment);
            bottomSheetDialog.dismiss();
        });

        bottomSheetBinding.option2.setOnClickListener(v -> {
            navController.navigate(R.id.imageEncryptionFragment);
            bottomSheetDialog.dismiss();
        });

        bottomSheetBinding.option3.setOnClickListener(v -> {
            navController.navigate(R.id.pdfEncryptionFragment);
            bottomSheetDialog.dismiss();
        });

        bottomSheetBinding.option4.setOnClickListener(v -> {
            navController.navigate(R.id.audioEncryptionFragment);
            bottomSheetDialog.dismiss();
        });

        bottomSheetBinding.option5.setOnClickListener(v -> {
            navController.navigate(R.id.videoEncryptionFragment);
            bottomSheetDialog.dismiss();
        });

        bottomSheetBinding.option6.setOnClickListener(v -> {
            navController.navigate(R.id.historyFragment);
            bottomSheetDialog.dismiss();
        });

        bottomSheetDialog.show();
    }
}
