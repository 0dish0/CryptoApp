package com.example.miniproject;

import java.util.ArrayList;
import java.util.List;

public class HistoryRepository {

    private static volatile HistoryRepository instance;
    private final List<HistoryItem> historyItems = new ArrayList<>();

    private HistoryRepository() {}

    public static HistoryRepository getInstance() {
        if (instance == null) {
            synchronized (HistoryRepository.class) {
                if (instance == null) {
                    instance = new HistoryRepository();
                }
            }
        }
        return instance;
    }

    public List<HistoryItem> getHistoryItems() {
        return historyItems;
    }

    public void addHistoryItem(HistoryItem item) {
        historyItems.add(0, item);
    }

    public void clearHistory() {
        historyItems.clear();
    }

    /**
     * Gets recent history items filtered by file type.
     * @param fileType Type to filter by ("text", "image", "pdf", "audio", "video")
     * @param limit Maximum number of items to return
     * @return List of recent items of the specified type
     */
    public List<HistoryItem> getRecentItemsByType(String fileType, int limit) {
        List<HistoryItem> filtered = new ArrayList<>();
        for (HistoryItem item : historyItems) {
            if (fileType.equals(item.getFileType())) {
                filtered.add(item);
                if (filtered.size() >= limit) {
                    break;
                }
            }
        }
        return filtered;
    }

    /**
     * Gets the most recent items across all types.
     * @param limit Maximum number of items to return
     * @return List of most recent items
     */
    public List<HistoryItem> getRecentItems(int limit) {
        List<HistoryItem> recent = new ArrayList<>();
        int count = Math.min(limit, historyItems.size());
        for (int i = 0; i < count; i++) {
            recent.add(historyItems.get(i));
        }
        return recent;
    }
}
