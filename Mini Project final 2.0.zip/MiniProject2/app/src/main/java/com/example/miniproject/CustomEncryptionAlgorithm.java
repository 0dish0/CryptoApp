package com.example.miniproject;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Interface for encryption algorithms in Cryptify.
 * All encryption algorithms must implement this interface.
 */
public interface CustomEncryptionAlgorithm {
    
    /**
     * Encrypts a string and returns Base64-encoded result.
     * @param plainText The text to encrypt
     * @param key The encryption key (algorithm-specific format)
     * @return Base64-encoded encrypted string
     * @throws Exception If encryption fails
     */
    String encryptString(String plainText, Object key) throws Exception;
    
    /**
     * Decrypts a Base64-encoded string.
     * @param encryptedText Base64-encoded encrypted text
     * @param key The decryption key (algorithm-specific format)
     * @return Decrypted plain text
     * @throws Exception If decryption fails
     */
    String decryptString(String encryptedText, Object key) throws Exception;
    
    /**
     * Encrypts data from an input stream to an output stream.
     * @param inputStream Source stream
     * @param outputStream Destination stream
     * @param key The encryption key (algorithm-specific format)
     * @throws Exception If encryption fails
     */
    void encryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception;
    
    /**
     * Decrypts data from an input stream to an output stream.
     * @param inputStream Source stream
     * @param outputStream Destination stream
     * @param key The decryption key (algorithm-specific format)
     * @throws Exception If decryption fails
     */
    void decryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception;
    
    /**
     * Gets the algorithm name.
     * @return Algorithm name (e.g., "AES", "XOR", "Twofish", "Serpent")
     */
    String getAlgorithmName();
    
    /**
     * Checks if the algorithm supports stream encryption.
     * @return true if stream encryption is supported
     */
    boolean supportsStreamEncryption();
}

