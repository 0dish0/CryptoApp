package com.example.miniproject;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.InputStream;
import java.io.OutputStream;

public class AudioEncryptionFragment extends Fragment {

    private static final int PICK_AUDIO_REQUEST = 3;

    private TextView audioFileNameText;
    private Button selectAudioButton;
    private Button encryptAudioButton;
    private Button decryptAudioButton;

    private Uri audioUri;
    private EncryptionAlgorithmManager algorithmManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Add Material Motion transition
        if (container != null) {
            setEnterTransition(new android.transition.Fade());
            setExitTransition(new android.transition.Fade());
        }
        
        View view = inflater.inflate(R.layout.fragment_audio_encryption, container, false);

        audioFileNameText = view.findViewById(R.id.audioFileNameText);
        selectAudioButton = view.findViewById(R.id.selectAudioButton);
        encryptAudioButton = view.findViewById(R.id.encryptAudioButton);
        decryptAudioButton = view.findViewById(R.id.decryptAudioButton);

        // Initialize algorithm manager
        algorithmManager = EncryptionAlgorithmManager.getInstance(requireContext());
        algorithmManager.loadAlgorithm();

        selectAudioButton.setOnClickListener(v -> openAudioChooser());
        encryptAudioButton.setOnClickListener(v -> processAudio(true));
        decryptAudioButton.setOnClickListener(v -> processAudio(false));

        return view;
    }

    private void openAudioChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("audio/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        String[] mimeTypes = {"audio/mpeg", "audio/wav", "audio/mp4", "audio/ogg", "audio/aac"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        startActivityForResult(Intent.createChooser(intent, "Select Audio"), PICK_AUDIO_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_AUDIO_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            audioUri = data.getData();
            String fileName = getFileName(audioUri);
            audioFileNameText.setText("Selected: " + fileName);
        }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (android.database.Cursor cursor = requireContext().getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (nameIndex >= 0) {
                        result = cursor.getString(nameIndex);
                    }
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result != null ? result : "Unknown Audio";
    }

    private String getFileExtension(String fileName) {
        int lastDot = fileName.lastIndexOf('.');
        if (lastDot > 0 && lastDot < fileName.length() - 1) {
            return fileName.substring(lastDot + 1).toLowerCase();
        }
        return "mp3"; // Default extension
    }

    private void processAudio(boolean isEncrypt) {
        if (audioUri == null) {
            Toast.makeText(getContext(), "Please select an audio file first.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            ContentResolver resolver = requireActivity().getContentResolver();
            InputStream inputStream = resolver.openInputStream(audioUri);

            String originalFileName = getFileName(audioUri);
            String extension = getFileExtension(originalFileName);
            String outputFileName = isEncrypt ? "encrypted_audio" : "decrypted_audio";
            outputFileName += "." + extension;

            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, outputFileName);
            
            // Set MIME type based on extension
            String mimeType = "audio/mpeg";
            switch (extension) {
                case "wav":
                    mimeType = "audio/wav";
                    break;
                case "m4a":
                    mimeType = "audio/mp4";
                    break;
                case "ogg":
                    mimeType = "audio/ogg";
                    break;
                case "aac":
                    mimeType = "audio/aac";
                    break;
            }
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC);

            Uri outputUri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            
            if (outputUri == null) {
                Toast.makeText(getContext(), "Error: Could not create output file", Toast.LENGTH_LONG).show();
                inputStream.close();
                return;
            }

            OutputStream outputStream = resolver.openOutputStream(outputUri);

            if (isEncrypt) {
                algorithmManager.encryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Encrypted Audio: " + outputFileName, System.currentTimeMillis(), "audio", outputFileName, false));
            } else {
                algorithmManager.decryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Decrypted Audio: " + outputFileName, System.currentTimeMillis(), "audio", outputFileName, false));
            }

            inputStream.close();
            outputStream.close();

            Toast.makeText(getContext(), 
                (isEncrypt ? "Encryption" : "Decryption") + " successful! Saved to Music", 
                Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("AudioEncryptionFragment", "Processing error", e);
            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload algorithm in case it was changed elsewhere
        if (algorithmManager != null) {
            algorithmManager.loadAlgorithm();
        }
    }
}

