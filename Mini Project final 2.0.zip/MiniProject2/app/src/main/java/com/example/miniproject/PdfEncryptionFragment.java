package com.example.miniproject;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.InputStream;
import java.io.OutputStream;

public class PdfEncryptionFragment extends Fragment {

    private static final int PICK_PDF_REQUEST = 2;

    private TextView pdfFileNameText;
    private Button selectPdfButton;
    private Button encryptPdfButton;
    private Button decryptPdfButton;

    private Uri pdfUri;
    private EncryptionAlgorithmManager algorithmManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Add Material Motion transition
        if (container != null) {
            setEnterTransition(new android.transition.Fade());
            setExitTransition(new android.transition.Fade());
        }
        
        View view = inflater.inflate(R.layout.fragment_pdf_encryption, container, false);

        pdfFileNameText = view.findViewById(R.id.pdfFileNameText);
        selectPdfButton = view.findViewById(R.id.selectPdfButton);
        encryptPdfButton = view.findViewById(R.id.encryptPdfButton);
        decryptPdfButton = view.findViewById(R.id.decryptPdfButton);

        // Initialize algorithm manager
        algorithmManager = EncryptionAlgorithmManager.getInstance(requireContext());
        algorithmManager.loadAlgorithm();

        selectPdfButton.setOnClickListener(v -> openPdfChooser());
        encryptPdfButton.setOnClickListener(v -> processPdf(true));
        decryptPdfButton.setOnClickListener(v -> processPdf(false));

        return view;
    }

    private void openPdfChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Select PDF"), PICK_PDF_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            pdfUri = data.getData();
            String fileName = getFileName(pdfUri);
            pdfFileNameText.setText("Selected: " + fileName);
        }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (android.database.Cursor cursor = requireContext().getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (nameIndex >= 0) {
                        result = cursor.getString(nameIndex);
                    }
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result != null ? result : "Unknown PDF";
    }

    private void processPdf(boolean isEncrypt) {
        if (pdfUri == null) {
            Toast.makeText(getContext(), "Please select a PDF file first.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            ContentResolver resolver = requireActivity().getContentResolver();
            InputStream inputStream = resolver.openInputStream(pdfUri);

            String outputFileName = isEncrypt ? "encrypted_document" : "decrypted_document";
            outputFileName += ".pdf";

            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, outputFileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

            Uri outputUri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            
            if (outputUri == null) {
                Toast.makeText(getContext(), "Error: Could not create output file", Toast.LENGTH_LONG).show();
                inputStream.close();
                return;
            }

            OutputStream outputStream = resolver.openOutputStream(outputUri);

            if (isEncrypt) {
                algorithmManager.encryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Encrypted PDF: " + outputFileName, System.currentTimeMillis(), "pdf", outputFileName, false));
            } else {
                algorithmManager.decryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Decrypted PDF: " + outputFileName, System.currentTimeMillis(), "pdf", outputFileName, false));
            }

            inputStream.close();
            outputStream.close();

            Toast.makeText(getContext(), 
                (isEncrypt ? "Encryption" : "Decryption") + " successful! Saved to Downloads", 
                Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("PdfEncryptionFragment", "Processing error", e);
            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload algorithm in case it was changed elsewhere
        if (algorithmManager != null) {
            algorithmManager.loadAlgorithm();
        }
    }
}

