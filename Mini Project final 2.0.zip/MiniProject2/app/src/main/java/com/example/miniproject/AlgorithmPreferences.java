package com.example.miniproject;

import android.content.Context;
import android.content.SharedPreferences;

public class AlgorithmPreferences {
    private static final String PREFS_NAME = "cryptify_prefs";
    private static final String KEY_ALGORITHM = "selected_algorithm";
    private static final String DEFAULT_ALGORITHM = "AES";

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static void setAlgorithm(Context context, String algorithm) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(KEY_ALGORITHM, algorithm);
        editor.apply();
    }

    public static String getAlgorithm(Context context) {
        return getSharedPreferences(context).getString(KEY_ALGORITHM, DEFAULT_ALGORITHM);
    }
}

