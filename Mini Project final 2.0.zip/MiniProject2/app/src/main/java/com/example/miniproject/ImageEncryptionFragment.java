package com.example.miniproject;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class ImageEncryptionFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView imageView;
    private Button selectImageButton;
    private Button encryptImageButton;
    private Button decryptImageButton;

    private Uri imageUri;
    private EncryptionAlgorithmManager algorithmManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Add Material Motion transition
        if (container != null) {
            setEnterTransition(new android.transition.Fade());
            setExitTransition(new android.transition.Fade());
        }
        
        View view = inflater.inflate(R.layout.fragment_image_encryption, container, false);

        imageView = view.findViewById(R.id.imageView);
        selectImageButton = view.findViewById(R.id.selectImageButton);
        encryptImageButton = view.findViewById(R.id.encryptImageButton);
        decryptImageButton = view.findViewById(R.id.decryptImageButton);

        // Initialize algorithm manager
        algorithmManager = EncryptionAlgorithmManager.getInstance(requireContext());
        algorithmManager.loadAlgorithm();

        selectImageButton.setOnClickListener(v -> openImageChooser());
        encryptImageButton.setOnClickListener(v -> processImage(true));
        decryptImageButton.setOnClickListener(v -> processImage(false));

        return view;
    }

    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }

    private void processImage(boolean isEncrypt) {
        if (imageUri == null) {
            Toast.makeText(getContext(), "Please select an image first.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            ContentResolver resolver = requireActivity().getContentResolver();
            InputStream inputStream = resolver.openInputStream(imageUri);

            String outputFileName = isEncrypt ? "encrypted_image" : "decrypted_image";
            outputFileName += ".jpg";

            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, outputFileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES);

            Uri outputUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            OutputStream outputStream = resolver.openOutputStream(outputUri);

            if (isEncrypt) {
                algorithmManager.encryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Encrypted Image: " + outputFileName, System.currentTimeMillis(), "image", outputFileName, false));
            } else {
                algorithmManager.decryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Decrypted Image: " + outputFileName, System.currentTimeMillis(), "image", outputFileName, false));
            }

            inputStream.close();
            outputStream.close();

            Toast.makeText(getContext(), (isEncrypt ? "Encryption" : "Decryption") + " successful! Saved to Pictures", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("ImageEncryptionFragment", "Processing error", e);
            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload algorithm in case it was changed elsewhere
        if (algorithmManager != null) {
            algorithmManager.loadAlgorithm();
        }
    }
}
