package com.example.miniproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class RecentActivityAdapter extends RecyclerView.Adapter<RecentActivityAdapter.RecentViewHolder> {

    private final List<HistoryItem> recentItems;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(HistoryItem item);
    }

    public RecentActivityAdapter(List<HistoryItem> recentItems, OnItemClickListener listener) {
        this.recentItems = recentItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recent_activity_item, parent, false);
        return new RecentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecentViewHolder holder, int position) {
        HistoryItem item = recentItems.get(position);
        holder.bind(item, listener);
    }

    @Override
    public int getItemCount() {
        return recentItems.size();
    }

    static class RecentViewHolder extends RecyclerView.ViewHolder {
        ImageView iconView;
        TextView titleView;
        TextView timestampView;

        public RecentViewHolder(@NonNull View itemView) {
            super(itemView);
            iconView = itemView.findViewById(R.id.recentIcon);
            titleView = itemView.findViewById(R.id.recentTitle);
            timestampView = itemView.findViewById(R.id.recentTimestamp);
        }

        void bind(HistoryItem item, OnItemClickListener listener) {
            // Set icon based on file type
            int iconRes = R.drawable.ic_text_format;
            switch (item.getFileType()) {
                case "image":
                    iconRes = R.drawable.ic_image;
                    break;
                case "pdf":
                    iconRes = R.drawable.ic_pdf;
                    break;
                case "audio":
                    iconRes = R.drawable.ic_audio;
                    break;
                case "video":
                    iconRes = R.drawable.ic_video;
                    break;
            }
            iconView.setImageResource(iconRes);

            // Set title (preview or filename)
            String title = item.getFilePath() != null ? item.getFilePath() : 
                (item.getText().length() > 30 ? item.getText().substring(0, 30) + "..." : item.getText());
            if (item.isPasswordMode()) {
                title += " (Password Mode)";
            }
            titleView.setText(title);

            // Set timestamp
            String formattedDate = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date(item.getTimestamp()));
            timestampView.setText(formattedDate);

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onItemClick(item);
                }
            });
        }
    }
}

