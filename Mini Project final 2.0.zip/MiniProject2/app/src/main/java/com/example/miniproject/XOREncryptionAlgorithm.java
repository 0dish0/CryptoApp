package com.example.miniproject;

import android.util.Base64;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * XOR encryption algorithm implementation.
 */
public class XOREncryptionAlgorithm implements CustomEncryptionAlgorithm {
    
    private static final String DEFAULT_KEY = "default_key";
    
    @Override
    public String encryptString(String plainText, Object key) throws Exception {
        String keyString = key instanceof String ? (String) key : DEFAULT_KEY;
        byte[] textBytes = plainText.getBytes("UTF-8");
        byte[] keyBytes = keyString.getBytes("UTF-8");
        byte[] encrypted = new byte[textBytes.length];
        
        for (int i = 0; i < textBytes.length; i++) {
            encrypted[i] = (byte) (textBytes[i] ^ keyBytes[i % keyBytes.length]);
        }
        
        return Base64.encodeToString(encrypted, Base64.DEFAULT);
    }
    
    @Override
    public String decryptString(String encryptedText, Object key) throws Exception {
        String keyString = key instanceof String ? (String) key : DEFAULT_KEY;
        byte[] encryptedBytes = Base64.decode(encryptedText, Base64.DEFAULT);
        byte[] keyBytes = keyString.getBytes("UTF-8");
        byte[] decrypted = new byte[encryptedBytes.length];
        
        for (int i = 0; i < encryptedBytes.length; i++) {
            decrypted[i] = (byte) (encryptedBytes[i] ^ keyBytes[i % keyBytes.length]);
        }
        
        return new String(decrypted, "UTF-8");
    }
    
    @Override
    public void encryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception {
        String keyString = key instanceof String ? (String) key : DEFAULT_KEY;
        byte[] keyBytes = keyString.getBytes("UTF-8");
        
        byte[] buffer = new byte[1024];
        int read;
        int keyIndex = 0;
        
        while ((read = inputStream.read(buffer)) != -1) {
            for (int i = 0; i < read; i++) {
                buffer[i] = (byte) (buffer[i] ^ keyBytes[keyIndex % keyBytes.length]);
                keyIndex++;
            }
            outputStream.write(buffer, 0, read);
        }
    }
    
    @Override
    public void decryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception {
        // XOR decryption is the same as encryption
        encryptStream(inputStream, outputStream, key);
    }
    
    @Override
    public String getAlgorithmName() {
        return "XOR";
    }
    
    @Override
    public boolean supportsStreamEncryption() {
        return true;
    }
}

