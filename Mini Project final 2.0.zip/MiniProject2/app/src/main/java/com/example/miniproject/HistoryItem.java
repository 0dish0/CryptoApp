package com.example.miniproject;

public class HistoryItem {
    private final String text;
    private final long timestamp;
    private final String fileType; // "text", "image", "pdf", "audio", "video"
    private final String filePath; // Optional file path or preview
    private final boolean isPasswordMode; // Whether PBE was used

    public HistoryItem(String text, long timestamp) {
        this(text, timestamp, "text", null, false);
    }

    public HistoryItem(String text, long timestamp, String fileType) {
        this(text, timestamp, fileType, null, false);
    }

    public HistoryItem(String text, long timestamp, String fileType, String filePath, boolean isPasswordMode) {
        this.text = text;
        this.timestamp = timestamp;
        this.fileType = fileType != null ? fileType : "text";
        this.filePath = filePath;
        this.isPasswordMode = isPasswordMode;
    }

    public String getText() {
        return text;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getFileType() {
        return fileType;
    }

    public String getFilePath() {
        return filePath;
    }

    public boolean isPasswordMode() {
        return isPasswordMode;
    }
}
