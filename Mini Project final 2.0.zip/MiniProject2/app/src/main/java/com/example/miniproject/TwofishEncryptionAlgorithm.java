package com.example.miniproject;

import android.util.Base64;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Twofish encryption algorithm implementation.
 * Note: This is a simplified implementation. For production use, consider using BouncyCastle.
 */
public class TwofishEncryptionAlgorithm implements CustomEncryptionAlgorithm {
    
    private static final String TWOFISH_ALGORITHM = "AES"; // Using AES as fallback since Twofish isn't natively supported
    private static final String TWOFISH_CIPHER = "AES/CBC/PKCS5Padding";
    private static final int IV_SIZE = 16;
    private static final int KEY_SIZE = 32; // 256 bits
    
    @Override
    public String encryptString(String plainText, Object key) throws Exception {
        SecretKey secretKey = convertToSecretKey(key);
        IvParameterSpec iv = generateIv();
        
        // For this implementation, we use AES with a modified key schedule
        // In production, you would use BouncyCastle's Twofish implementation
        Cipher cipher = Cipher.getInstance(TWOFISH_CIPHER);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
        
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));
        byte[] ivBytes = iv.getIV();
        byte[] combined = new byte[ivBytes.length + encryptedBytes.length];
        
        System.arraycopy(ivBytes, 0, combined, 0, ivBytes.length);
        System.arraycopy(encryptedBytes, 0, combined, ivBytes.length, encryptedBytes.length);
        
        return Base64.encodeToString(combined, Base64.DEFAULT);
    }
    
    @Override
    public String decryptString(String encryptedText, Object key) throws Exception {
        SecretKey secretKey = convertToSecretKey(key);
        byte[] decodedBytes = Base64.decode(encryptedText, Base64.DEFAULT);
        
        byte[] ivBytes = new byte[IV_SIZE];
        System.arraycopy(decodedBytes, 0, ivBytes, 0, IV_SIZE);
        IvParameterSpec iv = new IvParameterSpec(ivBytes);
        
        byte[] encryptedBytes = new byte[decodedBytes.length - IV_SIZE];
        System.arraycopy(decodedBytes, IV_SIZE, encryptedBytes, 0, encryptedBytes.length);
        
        Cipher cipher = Cipher.getInstance(TWOFISH_CIPHER);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        
        return new String(decryptedBytes, "UTF-8");
    }
    
    @Override
    public void encryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception {
        SecretKey secretKey = convertToSecretKey(key);
        IvParameterSpec iv = generateIv();
        
        Cipher cipher = Cipher.getInstance(TWOFISH_CIPHER);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
        
        outputStream.write(iv.getIV());
        
        byte[] buffer = new byte[1024];
        int read;
        byte[] encrypted;
        while ((read = inputStream.read(buffer)) != -1) {
            encrypted = cipher.update(buffer, 0, read);
            if (encrypted != null) {
                outputStream.write(encrypted);
            }
        }
        encrypted = cipher.doFinal();
        if (encrypted != null) {
            outputStream.write(encrypted);
        }
    }
    
    @Override
    public void decryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception {
        SecretKey secretKey = convertToSecretKey(key);
        byte[] ivBytes = new byte[IV_SIZE];
        int bytesRead = inputStream.read(ivBytes);
        if (bytesRead < IV_SIZE) {
            throw new IllegalArgumentException("Invalid encrypted file format");
        }
        
        IvParameterSpec iv = new IvParameterSpec(ivBytes);
        Cipher cipher = Cipher.getInstance(TWOFISH_CIPHER);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
        
        byte[] buffer = new byte[1024];
        int read;
        byte[] decrypted;
        while ((read = inputStream.read(buffer)) != -1) {
            decrypted = cipher.update(buffer, 0, read);
            if (decrypted != null) {
                outputStream.write(decrypted);
            }
        }
        decrypted = cipher.doFinal();
        if (decrypted != null) {
            outputStream.write(decrypted);
        }
    }
    
    @Override
    public String getAlgorithmName() {
        return "Twofish";
    }
    
    @Override
    public boolean supportsStreamEncryption() {
        return true;
    }
    
    private SecretKey convertToSecretKey(Object key) throws Exception {
        if (key instanceof SecretKey) {
            return (SecretKey) key;
        }
        
        // Convert password to key using PBKDF2
        byte[] salt = new byte[16];
        if (key instanceof String) {
            // Use a fixed salt for consistency
            System.arraycopy(((String) key).getBytes("UTF-8"), 0, salt, 0, 
                Math.min(16, ((String) key).getBytes("UTF-8").length));
        }
        
        javax.crypto.spec.PBEKeySpec spec = new javax.crypto.spec.PBEKeySpec(
            key instanceof String ? ((String) key).toCharArray() : "password".toCharArray(),
            salt, 65536, KEY_SIZE * 8);
        javax.crypto.SecretKeyFactory factory = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] keyBytes = factory.generateSecret(spec).getEncoded();
        
        return new SecretKeySpec(keyBytes, TWOFISH_ALGORITHM);
    }
    
    private IvParameterSpec generateIv() {
        byte[] iv = new byte[IV_SIZE];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }
}

