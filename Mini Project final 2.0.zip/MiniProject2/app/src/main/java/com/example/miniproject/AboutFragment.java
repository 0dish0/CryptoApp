package com.example.miniproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.miniproject.databinding.FragmentAboutBinding;

public class AboutFragment extends Fragment {

    private FragmentAboutBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentAboutBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String aboutText = "Cryptify is a modern Android application designed for secure encryption and decryption of digital content.\n" +
                "It supports text, images, audio files, and documents through robust and well-tested cryptographic algorithms.\n\n" +
                "Developed by Bhoomika A., Radhika N., and Disha C., the application focuses on delivering strong data protection while maintaining ease of use.\n\n" +
                "Key Features:\n" +
                "• Secure encryption and decryption for multiple media types\n" +
                "• Industry-standard cryptographic algorithms with optional custom modes\n" +
                "• Efficient key generation and optimized file processing\n" +
                "• Modular architecture for smooth handling of each media type\n" +
                "• Reliable performance and fast processing on Android devices\n" +
                "• User-friendly interface designed to simplify complex operations\n" +
                "• Enhanced storage practices to prevent unauthorized access\n\n" +
                "Cryptify demonstrates real-world implementation of encryption concepts and aims to provide a reliable, intuitive, and technically strong data-security solution for everyday users.";

        binding.aboutContent.setText(aboutText);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
