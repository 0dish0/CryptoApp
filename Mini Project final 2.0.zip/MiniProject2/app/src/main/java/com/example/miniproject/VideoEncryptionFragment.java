package com.example.miniproject;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.InputStream;
import java.io.OutputStream;

public class VideoEncryptionFragment extends Fragment {

    private static final int PICK_VIDEO_REQUEST = 4;

    private TextView videoFileNameText;
    private Button selectVideoButton;
    private Button encryptVideoButton;
    private Button decryptVideoButton;

    private Uri videoUri;
    private EncryptionAlgorithmManager algorithmManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Add Material Motion transition
        if (container != null) {
            setEnterTransition(new android.transition.Fade());
            setExitTransition(new android.transition.Fade());
        }
        
        View view = inflater.inflate(R.layout.fragment_video_encryption, container, false);

        videoFileNameText = view.findViewById(R.id.videoFileNameText);
        selectVideoButton = view.findViewById(R.id.selectVideoButton);
        encryptVideoButton = view.findViewById(R.id.encryptVideoButton);
        decryptVideoButton = view.findViewById(R.id.decryptVideoButton);

        // Initialize algorithm manager
        algorithmManager = EncryptionAlgorithmManager.getInstance(requireContext());
        algorithmManager.loadAlgorithm();

        selectVideoButton.setOnClickListener(v -> openVideoChooser());
        encryptVideoButton.setOnClickListener(v -> processVideo(true));
        decryptVideoButton.setOnClickListener(v -> processVideo(false));

        return view;
    }

    private void openVideoChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        String[] mimeTypes = {"video/mp4", "video/x-matroska", "video/quicktime"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        startActivityForResult(Intent.createChooser(intent, "Select Video"), PICK_VIDEO_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            videoUri = data.getData();
            String fileName = getFileName(videoUri);
            videoFileNameText.setText("Selected: " + fileName);
        }
    }

    private String getFileName(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (android.database.Cursor cursor = requireContext().getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (nameIndex >= 0) {
                        result = cursor.getString(nameIndex);
                    }
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            int cut = result.lastIndexOf('/');
            if (cut != -1) {
                result = result.substring(cut + 1);
            }
        }
        return result != null ? result : "Unknown Video";
    }

    private String getFileExtension(String fileName) {
        int lastDot = fileName.lastIndexOf('.');
        if (lastDot > 0 && lastDot < fileName.length() - 1) {
            return fileName.substring(lastDot + 1).toLowerCase();
        }
        return "mp4"; // Default extension
    }

    private void processVideo(boolean isEncrypt) {
        if (videoUri == null) {
            Toast.makeText(getContext(), "Please select a video file first.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            ContentResolver resolver = requireActivity().getContentResolver();
            InputStream inputStream = resolver.openInputStream(videoUri);

            String originalFileName = getFileName(videoUri);
            String extension = getFileExtension(originalFileName);
            String outputFileName = isEncrypt ? "encrypted_video" : "decrypted_video";
            outputFileName += "." + extension;

            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, outputFileName);
            
            // Set MIME type based on extension
            String mimeType = "video/mp4";
            switch (extension) {
                case "mkv":
                    mimeType = "video/x-matroska";
                    break;
                case "mov":
                    mimeType = "video/quicktime";
                    break;
            }
            values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES);

            Uri outputUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            
            if (outputUri == null) {
                Toast.makeText(getContext(), "Error: Could not create output file", Toast.LENGTH_LONG).show();
                inputStream.close();
                return;
            }

            OutputStream outputStream = resolver.openOutputStream(outputUri);

            if (isEncrypt) {
                algorithmManager.encryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Encrypted Video: " + outputFileName, System.currentTimeMillis(), "video", outputFileName, false));
            } else {
                algorithmManager.decryptStream(inputStream, outputStream);
                HistoryRepository.getInstance().addHistoryItem(
                    new HistoryItem("Decrypted Video: " + outputFileName, System.currentTimeMillis(), "video", outputFileName, false));
            }

            inputStream.close();
            outputStream.close();

            Toast.makeText(getContext(), 
                (isEncrypt ? "Encryption" : "Decryption") + " successful! Saved to Movies", 
                Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("VideoEncryptionFragment", "Processing error", e);
            Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload algorithm in case it was changed elsewhere
        if (algorithmManager != null) {
            algorithmManager.loadAlgorithm();
        }
    }
}

