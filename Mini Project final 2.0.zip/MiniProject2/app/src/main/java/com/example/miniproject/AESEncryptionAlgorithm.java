package com.example.miniproject;

import android.util.Base64;

import java.io.InputStream;
import java.io.OutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

/**
 * AES encryption algorithm implementation.
 */
public class AESEncryptionAlgorithm implements CustomEncryptionAlgorithm {
    
    private static final String AES_CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final int IV_SIZE = 16;
    
    @Override
    public String encryptString(String plainText, Object key) throws Exception {
        if (!(key instanceof SecretKey)) {
            throw new IllegalArgumentException("AES requires SecretKey");
        }
        
        SecretKey secretKey = (SecretKey) key;
        IvParameterSpec iv = EncryptionUtils.generateIv();
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
        
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));
        byte[] ivBytes = iv.getIV();
        byte[] combined = new byte[ivBytes.length + encryptedBytes.length];
        
        System.arraycopy(ivBytes, 0, combined, 0, ivBytes.length);
        System.arraycopy(encryptedBytes, 0, combined, ivBytes.length, encryptedBytes.length);
        
        return Base64.encodeToString(combined, Base64.DEFAULT);
    }
    
    @Override
    public String decryptString(String encryptedText, Object key) throws Exception {
        if (!(key instanceof SecretKey)) {
            throw new IllegalArgumentException("AES requires SecretKey");
        }
        
        SecretKey secretKey = (SecretKey) key;
        byte[] decodedBytes = Base64.decode(encryptedText, Base64.DEFAULT);
        
        byte[] ivBytes = new byte[IV_SIZE];
        System.arraycopy(decodedBytes, 0, ivBytes, 0, IV_SIZE);
        IvParameterSpec iv = new IvParameterSpec(ivBytes);
        
        byte[] encryptedBytes = new byte[decodedBytes.length - IV_SIZE];
        System.arraycopy(decodedBytes, IV_SIZE, encryptedBytes, 0, encryptedBytes.length);
        
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        
        return new String(decryptedBytes, "UTF-8");
    }
    
    @Override
    public void encryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception {
        if (!(key instanceof SecretKey)) {
            throw new IllegalArgumentException("AES requires SecretKey");
        }
        
        SecretKey secretKey = (SecretKey) key;
        IvParameterSpec iv = EncryptionUtils.generateIv();
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, iv);
        
        outputStream.write(iv.getIV());
        
        try (CipherOutputStream cos = new CipherOutputStream(outputStream, cipher)) {
            byte[] buffer = new byte[1024];
            int read;
            while ((read = inputStream.read(buffer)) != -1) {
                cos.write(buffer, 0, read);
            }
        }
    }
    
    @Override
    public void decryptStream(InputStream inputStream, OutputStream outputStream, Object key) throws Exception {
        if (!(key instanceof SecretKey)) {
            throw new IllegalArgumentException("AES requires SecretKey");
        }
        
        SecretKey secretKey = (SecretKey) key;
        byte[] ivBytes = new byte[IV_SIZE];
        int bytesRead = inputStream.read(ivBytes);
        if (bytesRead < IV_SIZE) {
            throw new IllegalArgumentException("Invalid encrypted file format");
        }
        
        IvParameterSpec iv = new IvParameterSpec(ivBytes);
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, iv);
        
        try (CipherInputStream cis = new CipherInputStream(inputStream, cipher)) {
            byte[] buffer = new byte[1024];
            int read;
            while ((read = cis.read(buffer)) != -1) {
                outputStream.write(buffer, 0, read);
            }
        }
    }
    
    @Override
    public String getAlgorithmName() {
        return "AES";
    }
    
    @Override
    public boolean supportsStreamEncryption() {
        return true;
    }
}

