package com.example.miniproject;

import android.util.Base64;

import java.io.InputStream;
import java.io.OutputStream;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class EncryptionUtils {

    private static final String AES = "AES";
    private static final String AES_CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final int AES_KEY_LENGTH = 256;
    private static final int IV_SIZE = 16;
    private static final String PBKDF2_ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int PBKDF2_ITERATIONS = 65536;
    private static final int SALT_SIZE = 16;

    public static SecretKey generateKey(char[] password, byte[] salt) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance(PBKDF2_ALGORITHM);
        KeySpec spec = new PBEKeySpec(password, salt, PBKDF2_ITERATIONS, AES_KEY_LENGTH);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), AES);
    }

    public static byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_SIZE];
        random.nextBytes(salt);
        return salt;
    }

    public static IvParameterSpec generateIv() {
        byte[] iv = new byte[IV_SIZE];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }

    public static String encrypt(String plainText, SecretKey key, IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key, iv);
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes("UTF-8"));

        byte[] ivBytes = iv.getIV();
        byte[] combined = new byte[ivBytes.length + encryptedBytes.length];
        System.arraycopy(ivBytes, 0, combined, 0, ivBytes.length);
        System.arraycopy(encryptedBytes, 0, combined, ivBytes.length, encryptedBytes.length);

        return Base64.encodeToString(combined, Base64.DEFAULT);
    }

    public static void encrypt(InputStream inputStream, OutputStream outputStream, SecretKey key, IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key, iv);

        outputStream.write(iv.getIV());

        try (CipherOutputStream cos = new CipherOutputStream(outputStream, cipher)) {
            byte[] buffer = new byte[1024];
            int read;
            while ((read = inputStream.read(buffer)) != -1) {
                cos.write(buffer, 0, read);
            }
        }
    }

    public static String decrypt(String encryptedText, SecretKey key) throws Exception {
        byte[] decodedBytes = Base64.decode(encryptedText, Base64.DEFAULT);

        byte[] ivBytes = new byte[IV_SIZE];
        System.arraycopy(decodedBytes, 0, ivBytes, 0, IV_SIZE);
        IvParameterSpec iv = new IvParameterSpec(ivBytes);

        byte[] encryptedBytes = new byte[decodedBytes.length - IV_SIZE];
        System.arraycopy(decodedBytes, IV_SIZE, encryptedBytes, 0, encryptedBytes.length);

        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return new String(decryptedBytes, "UTF-8");
    }

    public static void decrypt(InputStream inputStream, OutputStream outputStream, SecretKey key) throws Exception {
        byte[] ivBytes = new byte[IV_SIZE];
        int bytesRead = inputStream.read(ivBytes);
        if (bytesRead < IV_SIZE) {
            throw new IllegalArgumentException("Invalid encrypted file format");
        }
        IvParameterSpec iv = new IvParameterSpec(ivBytes);

        Cipher cipher = Cipher.getInstance(AES_CIPHER_ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key, iv);

        try (CipherInputStream cis = new CipherInputStream(inputStream, cipher)) {
            byte[] buffer = new byte[1024];
            int read;
            while ((read = cis.read(buffer)) != -1) {
                outputStream.write(buffer, 0, read);
            }
        }
    }

    public static boolean isBase64(String str) {
        try {
            Base64.decode(str, Base64.DEFAULT);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // XOR Cipher methods
    public static String encryptXOR(String plainText, String key) {
        byte[] textBytes = plainText.getBytes();
        byte[] keyBytes = key.getBytes();
        byte[] encrypted = new byte[textBytes.length];
        
        for (int i = 0; i < textBytes.length; i++) {
            encrypted[i] = (byte) (textBytes[i] ^ keyBytes[i % keyBytes.length]);
        }
        
        return Base64.encodeToString(encrypted, Base64.DEFAULT);
    }

    public static String decryptXOR(String encryptedText, String key) {
        byte[] encryptedBytes = Base64.decode(encryptedText, Base64.DEFAULT);
        byte[] keyBytes = key.getBytes();
        byte[] decrypted = new byte[encryptedBytes.length];
        
        for (int i = 0; i < encryptedBytes.length; i++) {
            decrypted[i] = (byte) (encryptedBytes[i] ^ keyBytes[i % keyBytes.length]);
        }
        
        return new String(decrypted);
    }

    // Algorithm-agnostic encryption methods
    public static String encryptWithAlgorithm(String plainText, String algorithm, SecretKey key, IvParameterSpec iv, String xorKey) throws Exception {
        if ("XOR".equals(algorithm)) {
            return encryptXOR(plainText, xorKey != null ? xorKey : "default_key");
        } else if ("CUSTOM".equals(algorithm)) {
            // Placeholder for custom algorithm
            return encrypt(plainText, key, iv);
        } else {
            // Default to AES
            return encrypt(plainText, key, iv);
        }
    }

    public static String decryptWithAlgorithm(String encryptedText, String algorithm, SecretKey key, String xorKey) throws Exception {
        if ("XOR".equals(algorithm)) {
            return decryptXOR(encryptedText, xorKey != null ? xorKey : "default_key");
        } else if ("CUSTOM".equals(algorithm)) {
            // Placeholder for custom algorithm
            return decrypt(encryptedText, key);
        } else {
            // Default to AES
            return decrypt(encryptedText, key);
        }
    }
}
